package com.simplicity.client;

public class OnDemandFetcherParent {
	
    public void get(int i)
    {
    }
    
    public void get(int type, int i)
    {
    }

    public OnDemandFetcherParent()
    {
    }
    
}
