package com.simplicity.client;



public final class GroundDecoration
{

	public GroundDecoration()
	{
	}

	int zPos;
	int xPos;
	int yPos;
	public Animable node;
	public int uid;
	int groundDecorUID;
	byte objConfig;
}
