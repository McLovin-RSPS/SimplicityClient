package com.simplicity.client;



public final class WallObject
{

	public WallObject()
	{
	}

	int zPos;
	int xPos;
	int yPos;
	int orientation;
	int orientation1;
	public Animable node1;
	public Animable node2;
	public int uid;
	int wallObjUID;
	byte objConfig;
}
