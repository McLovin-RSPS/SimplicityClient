package com.simplicity.client;



public final class DummyClass {

	public DummyClass()
	{
	}

	public static DummyClass cache[];
}
