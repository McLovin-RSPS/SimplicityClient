package com.simplicity.client;



final class GroundItem {

	GroundItem()
	{
	}

	int zPos;
	int xPos;
	int yPos;
	Animable firstGroundItem;
	Animable secondGroundItem;
	Animable thirdGroundItem;
	int uid;
	int newuid;
	int topItem;
}
