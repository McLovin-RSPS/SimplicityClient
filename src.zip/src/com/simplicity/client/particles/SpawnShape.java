package com.simplicity.client.particles;

import java.util.Random;

public interface SpawnShape {
	
	ParticleVector divide(Random random);
}
