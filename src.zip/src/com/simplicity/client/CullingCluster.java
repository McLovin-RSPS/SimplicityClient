package com.simplicity.client;


// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

final class CullingCluster {

	CullingCluster() {
	}

	int tileStartX;
	int tileEndX;
	int tileStartY;
	int tileEndY;
	int searchMask;
	int worldStartX;
	int worldEndX;
	int worldStartY;
	int worldEndY;
	int worldStartZ;
	int worldEndZ;
	int tileDistanceEnum;
	int worldDistanceFromCameraStartX;
	int worldDistanceFromCameraEndX;
	int worldDistanceFromCameraStartY;
	int worldDistanceFromCameraEndY;
	int worldDistanceFromCameraStartZ;
	int worldDistanceFromCameraEndZ;
}
