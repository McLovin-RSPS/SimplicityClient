package com.simplicity.client;

import com.simplicity.client.particles.ParticleVector;

import java.util.Random;

public interface SpawnShape {
	
	ParticleVector divide(Random random);
}
