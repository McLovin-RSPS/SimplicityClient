package com.simplicity.client;



public final class WallDecoration
{

	public WallDecoration()
	{
	}

	int zPos;
	int xPos;
	int yPos;
	int configurationBits;
	int rotation;
	public Animable node;
	public int uid;
	int wallDecorUID;
	byte objConfig;
}
