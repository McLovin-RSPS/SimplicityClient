package com.simplicity.client;



public final class InteractableObject
{

	public InteractableObject()
	{
	}

	int zPos;
	int worldZ;
	int worldX;
	int worldY;
	public Animable node;
	public int rotation;
	int tileLeft;
	int tileRight;
	int tileTop;
	int tileBottom;
	int anInt527;
	int height;
	public int uid;
	int interactiveObjUID;
	byte objConf;
}
