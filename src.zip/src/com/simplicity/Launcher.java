package com.simplicity;
import com.simplicity.client.Splash;

import javax.swing.*;
 
 /**
  * @author Pwnhub
  */
public class Launcher {


}